# Claude Code 提示词 — SonyEdge 应用图标落地(方案 2c:橙环 + α)

> 用法:先把本项目 `handoff/screens/icon-2c.png` 拷入仓库 `docs/design/redesign-v1/icon-2c.png`(视觉基准,含 96/72圆形/48 三档尺寸),然后在仓库根目录运行 Claude Code,粘贴下面整段。

---

你是 Android 工程师,为 SonyEdge 替换应用启动图标。设计已定稿(方案 2c「橙环 + α」),视觉基准见 `docs/design/redesign-v1/icon-2c.png`。开工前先看图。

## 设计描述

深石墨圆角方形底上一枚居中镜头:黑色镜筒外圈套一圈**琥珀橙环**(呼应索尼 α 卡口环),环外留一细圈石墨间隙;镜筒内是深灰内环 + 左上带高光的玻璃球面;右上角一个粗体琥珀**希腊字母 α**(通用无衬线字形,不是索尼官方 α 商标字形——不得临摹官方 logo)。

## 精确规格(以 108×108dp Adaptive Icon 画布为基准)

**背景层** `res/drawable/ic_launcher_background.xml`(vector 或 gradient):
- 线性渐变 160°:#23252A → #131417,铺满 108dp

**前景层** `res/drawable/ic_launcher_foreground.xml`(vector,所有元素落在中央 66dp 安全区内):
- 镜头组居中,整体外径 46dp:
  - 石墨间隙环:圆 d=46dp,填充 #17181B
  - 琥珀环:圆 d=40dp,填充 #E8A33C
  - 镜筒:圆 d=34dp,填充 #0B0C0E
  - 内环:圆 d=23dp,填充 #1B1D21
  - 玻璃:圆 d=17dp,填充 #101216;左上叠加高光小圆 d=7dp,#4A5058,圆心偏 (-2.5dp, -2.5dp)(vector 里用两层实心圆近似渐变即可)
- α 字符:粗体无衬线(用路径,不引字体;可从 Noto Sans Bold 的 U+03B1 取轮廓转 path),cap 高约 11dp,填充 #E8A33C,基线右上位置:字符右缘距安全区右缘 2dp、顶缘距安全区顶缘 1dp
- 前景整体不要触碰 66dp 安全区边缘之外(各厂商蒙版会裁切)

**Monochrome 层**(Android 13+ 主题图标,`<monochrome>`):
- 仅保留:琥珀环(改为描边圆环,stroke 3dp)+ α 路径,单色 path,不含背景

**通知小图标** `res/drawable/ic_stat_sonyedge.xml`:
- 24dp,白色单色:圆环(stroke 2dp,d=16dp)+ 右上 α(cap 高 7dp);替换 DownloadService 通知里现用的 small icon 引用

## 交付与替换

1. 更新 `res/mipmap-anydpi-v26/ic_launcher.xml` 与 `ic_launcher_round.xml`:引用新的 background/foreground/monochrome
2. 重新生成各密度 legacy PNG(mdpi 48 / hdpi 72 / xhdpi 96 / xxhdpi 144 / xxxhdpi 192,含 round):可用 vector 渲染脚本或 Android Studio Image Asset;圆角方形版圆角半径 ≈ 边长 22%
3. 删除/替换旧的 `drawable-nodpi/ic_launcher_artwork.png` 引用(若仍被使用)
4. `./gradlew assembleDebug` 通过;安装后核对:launcher 大图标、设置-应用信息小图标、Android 13 主题图标、下载通知小图标四处显示正常
5. 单独 commit,信息:`feat: 新应用图标(橙环镜头 + α)`

## 红线

- 不使用 SONY 字标、官方 α 商标字形或任何官方位图素材;α 必须是通用字体轮廓转的 path
- 不改动除图标资源与其引用之外的任何代码
